from __future__ import annotations

import argparse
import json
from pathlib import Path

from c3kasa.config import load_yaml, stable_hash


parser = argparse.ArgumentParser()
parser.add_argument("--config", required=True)
parser.add_argument("--run-dir", required=True)
args = parser.parse_args()
cfg = load_yaml(args.config)
out = Path(args.run_dir)
out.mkdir(parents=True, exist_ok=True)
record = {"status": "configured", "config_hash": stable_hash(cfg), "folds": cfg["folds"], "seeds": cfg["seeds"]}
(out / "control_plan.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps(record, sort_keys=True))
