from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from c3kasa.data import audit_manifest
from c3kasa.io import write_json


parser = argparse.ArgumentParser()
parser.add_argument("--manifest", required=True)
parser.add_argument("--out", required=True)
args = parser.parse_args()
report = audit_manifest(pd.read_csv(args.manifest))
write_json(Path(args.out) / "audit_report.json", report)
print(report)
