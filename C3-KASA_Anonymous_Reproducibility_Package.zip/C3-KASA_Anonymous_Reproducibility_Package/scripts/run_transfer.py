from __future__ import annotations

import argparse
import json
from pathlib import Path

from c3kasa.config import load_yaml


parser = argparse.ArgumentParser()
parser.add_argument("--config", required=True)
parser.add_argument("--run-dir", required=True)
args = parser.parse_args()
cfg = load_yaml(args.config)
for corpus in ("asian_l1", "european_l1"):
    part = cfg[corpus]
    assert part["total_speakers"] == part["fixed_test_speakers"] + part["calibration_only_speakers"] + part["adaptation_pool_speakers"]
    assert part["nested_adaptation_speakers"][-1] == part["adaptation_pool_speakers"]
out = Path(args.run_dir)
out.mkdir(parents=True, exist_ok=True)
(out / "partition_check.json").write_text(json.dumps({"status": "passed", "config": cfg}, indent=2) + "\n", encoding="utf-8")
