from __future__ import annotations

import argparse
import json

import numpy as np
import pandas as pd

from c3kasa.metrics import metric_bundle


parser = argparse.ArgumentParser()
parser.add_argument("--predictions", required=True)
parser.add_argument("--out", required=True)
args = parser.parse_args()
frame = pd.read_csv(args.predictions)
result = {}
for construct, group in frame.groupby("construct"):
    columns = [f"p{index}" for index in range(6)]
    predictive = metric_bundle(group["label"].to_numpy(), group[columns].to_numpy())
    entry = {"predictive": predictive}
    calibrated_columns = [f"calibrated_p{index}" for index in range(6)]
    if set(calibrated_columns).issubset(group.columns):
        calibrated = metric_bundle(group["label"].to_numpy(), group[calibrated_columns].to_numpy())
        entry["calibration"] = {key: calibrated[key] for key in ("nll", "brier", "ece")}
    result[construct] = entry
with open(args.out, "w", encoding="utf-8") as handle:
    json.dump(result, handle, indent=2)
    handle.write("\n")
