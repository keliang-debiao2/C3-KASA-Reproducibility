from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader

from c3kasa.calibration import class_probabilities_from_cumulative
from c3kasa.config import load_yaml
from c3kasa.data import FeatureDataset
from c3kasa.model import C3KASA, CONSTRUCTS


parser = argparse.ArgumentParser()
parser.add_argument("--checkpoint", required=True)
parser.add_argument("--config", required=True)
parser.add_argument("--fold", type=int, required=True, choices=range(1, 6))
parser.add_argument("--role", required=True, choices=("train", "selection", "calibration", "test"))
parser.add_argument("--calibration")
parser.add_argument("--out", required=True)
parser.add_argument("--batch-size", type=int, default=128)
args = parser.parse_args()
cfg = load_yaml(args.config)
calibration = json.loads(Path(args.calibration).read_text(encoding="utf-8")) if args.calibration else {}
checkpoint = torch.load(args.checkpoint, map_location="cpu")
model = C3KASA(cfg["model"]["input_dims"], cfg["model"]["common_dim"], cfg["model"]["classes"], cfg["model"]["dropout"])
model.load_state_dict(checkpoint["model"])
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device).eval()

features = pd.read_csv(cfg["data"]["feature_manifest"])
roles = pd.read_csv(Path(cfg["data"]["split_root"]) / "partition_matrix.csv")
roles = roles[(roles["outer_fold"] == args.fold) & (roles["role"] == args.role)][["speaker_id", "role"]]
features["speaker_id"] = features["speaker_id"].astype(str)
roles["speaker_id"] = roles["speaker_id"].astype(str)
frame = features.merge(roles, on="speaker_id", validate="many_to_one")
if frame.empty:
    raise SystemExit("No responses were found for the selected outer-fold role")
loader = DataLoader(FeatureDataset(frame), batch_size=args.batch_size, shuffle=False, num_workers=0)
rows = []
with torch.no_grad():
    for batch in loader:
        values = {name: batch[name].to(device) for name in cfg["model"]["input_dims"]}
        output = model(values)
        for construct_index, construct in enumerate(CONSTRUCTS):
            raw = output[construct]["probabilities"]
            latent = output[construct]["latent"]
            thresholds = model.ordinal[construct].thresholds()
            if construct in calibration:
                temperature = float(calibration[construct]["temperature"])
                cumulative = torch.sigmoid((latent[:, None] - thresholds[None, :]) / temperature)
                calibrated = class_probabilities_from_cumulative(cumulative)
            else:
                temperature = 1.0
                calibrated = raw
            raw_np = raw.cpu().numpy()
            calibrated_np = calibrated.cpu().numpy()
            expected = raw_np @ np.arange(raw_np.shape[1])
            calibrated_expected = calibrated_np @ np.arange(calibrated_np.shape[1])
            uncertainty = output[construct]["uncertainty"].cpu().numpy()
            for index, response_id in enumerate(batch["response_id"]):
                row = {
                    "response_id": str(response_id),
                    "speaker_id": str(batch["speaker_id"][index]),
                    "outer_fold": args.fold,
                    "role": args.role,
                    "construct": construct,
                    "label": int(batch["labels"][index, construct_index]),
                    "latent": float(latent[index].cpu()),
                    "expected": float(expected[index]),
                    "calibrated_expected": float(calibrated_expected[index]),
                    "temperature": temperature,
                    "uncertainty": float(uncertainty[index]),
                }
                row.update({f"threshold_{j}": float(value) for j, value in enumerate(thresholds.cpu().tolist())})
                row.update({f"p{j}": float(value) for j, value in enumerate(raw_np[index])})
                row.update({f"calibrated_p{j}": float(value) for j, value in enumerate(calibrated_np[index])})
                rows.append(row)
out = Path(args.out)
out.parent.mkdir(parents=True, exist_ok=True)
pd.DataFrame(rows).to_csv(out, index=False)
print(json.dumps({"rows": len(rows), "responses": len(frame), "fold": args.fold, "role": args.role}, sort_keys=True))
