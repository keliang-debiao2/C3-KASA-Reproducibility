from __future__ import annotations

import argparse
import json
from pathlib import Path


parser = argparse.ArgumentParser()
parser.add_argument("--predictions-root", required=True)
parser.add_argument("--out", required=True)
args = parser.parse_args()
out = Path(args.out)
out.mkdir(parents=True, exist_ok=True)
plan = {
    "cluster_unit": "speaker_id",
    "bootstrap_resamples": 10000,
    "permutation_resamples": 10000,
    "family_a_comparisons": 8,
    "multiplicity": "Holm",
    "family_b": "worst_group_mae",
}
(out / "statistical_plan.json").write_text(json.dumps(plan, indent=2) + "\n", encoding="utf-8")
