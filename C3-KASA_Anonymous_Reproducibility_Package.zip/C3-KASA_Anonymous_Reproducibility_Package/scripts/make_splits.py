from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from c3kasa.data import grouped_folds, partition_matrix
from c3kasa.io import write_json


parser = argparse.ArgumentParser()
parser.add_argument("--manifest", required=True)
parser.add_argument("--out", required=True)
parser.add_argument("--seed", type=int, default=2026)
args = parser.parse_args()
frame = pd.read_csv(args.manifest)
assignment = grouped_folds(frame, n_folds=5, seed=args.seed)
out = Path(args.out)
out.mkdir(parents=True, exist_ok=True)
frame.assign(outer_fold=frame["speaker_id"].astype(str).map(assignment)).to_csv(out / "outer_folds.csv", index=False)
roles = partition_matrix(frame, assignment, n_folds=5, seed=args.seed)
roles.to_csv(out / "partition_matrix.csv", index=False)
role_counts = {
    str(fold): {str(role): int(count) for role, count in group["role"].value_counts().items()}
    for fold, group in roles.groupby("outer_fold")
}
write_json(out / "split_metadata.json", {"seed": args.seed, "folds": 5, "speakers": len(assignment), "role_counts": role_counts})
