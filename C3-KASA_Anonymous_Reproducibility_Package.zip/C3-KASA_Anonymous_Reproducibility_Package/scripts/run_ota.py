from __future__ import annotations

import argparse
import json
from pathlib import Path

from c3kasa.config import load_yaml


parser = argparse.ArgumentParser()
parser.add_argument("--config", required=True)
parser.add_argument("--run-dir", required=True)
args = parser.parse_args()
cfg = load_yaml(args.config)
assert len(cfg["conditions"]) == 9
assert cfg["recordings_per_condition"] * len(cfg["conditions"]) == cfg["total_rerecordings"]
assert cfg["subset_responses"] * 3 == cfg["severe_disagreement_denominator_per_condition"]
out = Path(args.run_dir)
out.mkdir(parents=True, exist_ok=True)
(out / "ota_plan.json").write_text(json.dumps({"status": "passed", "config": cfg}, indent=2) + "\n", encoding="utf-8")
