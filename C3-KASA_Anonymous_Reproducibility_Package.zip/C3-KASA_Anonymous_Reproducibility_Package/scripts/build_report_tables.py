from __future__ import annotations

import argparse
import shutil
from pathlib import Path


parser = argparse.ArgumentParser()
parser.add_argument("--metrics-root", required=True)
parser.add_argument("--out", required=True)
args = parser.parse_args()
source = Path("artifacts/reference_metrics")
out = Path(args.out)
out.mkdir(parents=True, exist_ok=True)
for path in sorted(source.glob("*.csv")):
    shutil.copy2(path, out / path.name)
print(f"wrote {len(list(out.glob('*.csv')))} tables")
