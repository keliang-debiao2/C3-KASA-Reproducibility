from __future__ import annotations

import argparse
import json

import numpy as np
import pandas as pd
import torch

from c3kasa.calibration import class_probabilities_from_cumulative, fit_temperature, higher_finite_quantile


parser = argparse.ArgumentParser()
parser.add_argument("--predictions", required=True)
parser.add_argument("--out", required=True)
args = parser.parse_args()
frame = pd.read_csv(args.predictions)
required = {"speaker_id", "construct", "label", "latent", *(f"threshold_{index}" for index in range(5))}
missing = sorted(required - set(frame.columns))
if missing:
    raise SystemExit(f"Missing columns: {missing}")
result = {}
for construct, group in frame.groupby("construct"):
    latent = torch.tensor(group["latent"].to_numpy(), dtype=torch.float32)
    thresholds = torch.tensor(group[[f"threshold_{index}" for index in range(5)]].iloc[0].to_numpy(), dtype=torch.float32)
    labels = torch.tensor(group["label"].to_numpy(), dtype=torch.long)
    temperature = fit_temperature(latent, thresholds, labels)
    cumulative = torch.sigmoid((latent[:, None] - thresholds[None, :]) / temperature)
    probabilities = class_probabilities_from_cumulative(cumulative).detach().numpy()
    calibrated_expected = probabilities @ np.arange(6, dtype=float)
    scores = np.abs(group["label"].to_numpy() - calibrated_expected)
    indexed = pd.Series(scores, index=group.index)
    per_speaker = [higher_finite_quantile(part.to_numpy(), 0.10) for _, part in indexed.groupby(group["speaker_id"])]
    result[construct] = {"temperature": temperature, "q90": higher_finite_quantile(np.asarray(per_speaker), 0.10), "calibration_responses": int(len(group)), "calibration_speakers": int(group["speaker_id"].nunique())}
with open(args.out, "w", encoding="utf-8") as handle:
    json.dump(result, handle, indent=2)
    handle.write("\n")
