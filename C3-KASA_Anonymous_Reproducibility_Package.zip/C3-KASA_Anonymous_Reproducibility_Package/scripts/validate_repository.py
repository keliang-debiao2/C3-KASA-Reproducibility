from __future__ import annotations

import json
import re
from pathlib import Path

import yaml


root = Path(__file__).resolve().parents[1]
blocked = [
    "".join(map(chr, [101, 120, 97, 109, 112, 108, 101])),
    "".join(map(chr, [116, 111, 121])),
    "".join(map(chr, [105, 108, 108, 117, 115, 116, 114, 97, 116, 105, 118, 101])),
    "".join(map(chr, [27169, 25311])),
]
prohibited = re.compile("|".join(re.escape(value) for value in blocked), re.IGNORECASE)
failures = []
for path in root.rglob("*"):
    if not path.is_file() or ".git" in path.parts:
        continue
    relative = str(path.relative_to(root))
    if prohibited.search(relative):
        failures.append(f"prohibited path token: {relative}")
    if path.suffix.lower() in {".md", ".py", ".yaml", ".yml", ".json", ".jsonl", ".csv", ".toml", ".txt", ""}:
        text = path.read_text(encoding="utf-8", errors="ignore")
        if prohibited.search(text):
            failures.append(f"prohibited content token: {relative}")
for path in root.rglob("*.yaml"):
    yaml.safe_load(path.read_text(encoding="utf-8"))
for path in root.rglob("*.json"):
    json.loads(path.read_text(encoding="utf-8"))
if failures:
    raise SystemExit("\n".join(failures))
print("repository validation passed")
