from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import torch
from torch.utils.data import DataLoader

from c3kasa.config import load_yaml, stable_hash
from c3kasa.data import FeatureDataset
from c3kasa.io import append_jsonl, write_json
from c3kasa.losses import joint_loss
from c3kasa.model import C3KASA
from c3kasa.seed import set_global_seed


parser = argparse.ArgumentParser()
parser.add_argument("--config", required=True)
parser.add_argument("--fold", type=int, required=True, choices=range(1, 6))
parser.add_argument("--seed", type=int, default=2026)
parser.add_argument("--run-dir", required=True)
args = parser.parse_args()
cfg = load_yaml(args.config)
set_global_seed(args.seed, cfg.get("deterministic", True))
run_dir = Path(args.run_dir)
run_dir.mkdir(parents=True, exist_ok=True)
write_json(run_dir / "run_metadata.json", {"config_hash": stable_hash(cfg), "fold": args.fold, "seed": args.seed})

feature_frame = pd.read_csv(cfg["data"]["feature_manifest"])
split_frame = pd.read_csv(Path(cfg["data"]["split_root"]) / "partition_matrix.csv")
split_frame = split_frame[split_frame["outer_fold"] == args.fold][["speaker_id", "role"]]
split_frame["speaker_id"] = split_frame["speaker_id"].astype(str)
feature_frame["speaker_id"] = feature_frame["speaker_id"].astype(str)
frame = feature_frame.merge(split_frame, on="speaker_id", validate="many_to_one")
train = frame[frame.role == "train"].copy()
if train.empty:
    raise SystemExit("The training role is empty for the selected outer fold")
loader = DataLoader(FeatureDataset(train), batch_size=cfg["optimization"]["batch_size"], shuffle=True, num_workers=0)
model = C3KASA(cfg["model"]["input_dims"], cfg["model"]["common_dim"], cfg["model"]["classes"], cfg["model"]["dropout"])
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)
optimizer = torch.optim.AdamW(model.parameters(), lr=cfg["optimization"]["new_module_lr"], weight_decay=cfg["optimization"]["weight_decay"])
for epoch in range(1, cfg["optimization"]["epochs"] + 1):
    model.train()
    total = 0.0
    for batch in loader:
        features = {key: batch[key].to(device) for key in cfg["model"]["input_dims"]}
        labels = batch["labels"].to(device)
        optimizer.zero_grad(set_to_none=True)
        output = model(features)
        loss, parts = joint_loss(output, labels, cfg["loss_weights"]["ccc"], cfg["loss_weights"]["evidence"], cfg["loss_weights"]["orthogonality"])
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), cfg["optimization"]["gradient_clip"])
        optimizer.step()
        total += float(loss.detach())
    event = {"event": "epoch_end", "epoch": epoch, "mean_loss": total / max(1, len(loader)), "fold": args.fold, "seed": args.seed}
    append_jsonl(run_dir / "train.jsonl", event)
    print(json.dumps(event, sort_keys=True))
torch.save({"model": model.state_dict(), "config": cfg, "fold": args.fold, "seed": args.seed}, run_dir / "model.pt")
