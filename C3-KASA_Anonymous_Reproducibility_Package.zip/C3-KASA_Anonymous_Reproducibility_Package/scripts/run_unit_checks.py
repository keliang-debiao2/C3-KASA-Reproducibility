from __future__ import annotations

import importlib.util
import runpy
from pathlib import Path


root = Path(__file__).resolve().parents[1]
count = 0
skipped = []
has_torch = importlib.util.find_spec("torch") is not None
for path in sorted((root / "tests").glob("test_*.py")):
    if path.name == "test_model.py" and not has_torch:
        skipped.append(f"{path.name}: torch unavailable")
        continue
    namespace = runpy.run_path(str(path))
    for name, value in sorted(namespace.items()):
        if name.startswith("test_") and callable(value):
            value()
            count += 1
print(f"unit checks passed: {count}")
if skipped:
    print("dependency-bound checks skipped: " + "; ".join(skipped))
