from __future__ import annotations

import numpy as np
import pandas as pd


def clustered_bootstrap_difference(frame: pd.DataFrame, cluster: str, left: str, right: str, resamples: int = 10000, seed: int = 2026) -> dict[str, float]:
    grouped = {key: group for key, group in frame.groupby(cluster, sort=True)}
    keys = np.array(list(grouped))
    rng = np.random.default_rng(seed)
    observed = float((frame[left] - frame[right]).mean())
    values = np.empty(resamples, dtype=float)
    for index in range(resamples):
        selected = rng.choice(keys, size=len(keys), replace=True)
        chunks = [grouped[key] for key in selected]
        joined = pd.concat(chunks, ignore_index=True)
        values[index] = (joined[left] - joined[right]).mean()
    return {"difference": observed, "ci_low": float(np.quantile(values, 0.025)), "ci_high": float(np.quantile(values, 0.975))}


def paired_permutation(frame: pd.DataFrame, cluster: str, left: str, right: str, resamples: int = 10000, seed: int = 2026) -> float:
    difference = frame.assign(delta=frame[left] - frame[right]).groupby(cluster)["delta"].mean().to_numpy()
    observed = abs(difference.mean())
    rng = np.random.default_rng(seed)
    exceed = 0
    for _ in range(resamples):
        signs = rng.choice(np.array([-1.0, 1.0]), size=difference.size)
        exceed += abs(np.mean(difference * signs)) >= observed
    return float((exceed + 1) / (resamples + 1))


def holm_adjust(p_values: list[float]) -> list[float]:
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values), dtype=float)
    running = 0.0
    total = len(p_values)
    for rank, index in enumerate(order):
        running = max(running, (total - rank) * p_values[index])
        adjusted[index] = min(1.0, running)
    return adjusted.tolist()
