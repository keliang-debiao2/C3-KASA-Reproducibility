from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np
import pandas as pd
try:
    import torch
    from torch.utils.data import Dataset
except ModuleNotFoundError:
    torch = None

    class Dataset:
        pass


STREAMS = ("speech_semantic", "asr", "pronunciation_prosody", "morphosyntax", "prompt_content")
LABELS = ("delivery", "language_use", "content")


def sha256_file(path: str | Path, chunk_size: int = 1 << 20) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def audit_manifest(frame: pd.DataFrame) -> dict:
    required = {"response_id", "speaker_id", "prompt_id", *LABELS}
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"Missing columns: {missing}")
    duplicate_ids = int(frame["response_id"].duplicated().sum())
    invalid_labels = int((~frame[list(LABELS)].isin(range(6))).sum().sum())
    return {
        "rows": int(len(frame)),
        "speakers": int(frame["speaker_id"].nunique()),
        "prompts": int(frame["prompt_id"].nunique()),
        "duplicate_response_ids": duplicate_ids,
        "invalid_label_cells": invalid_labels,
        "label_counts": {
            label: {str(k): int(v) for k, v in frame[label].value_counts().sort_index().items()}
            for label in LABELS
        },
    }


def grouped_folds(frame: pd.DataFrame, n_folds: int = 5, seed: int = 2026) -> dict[str, int]:
    counts = frame.groupby("speaker_id").size().rename("n").reset_index()
    rng = np.random.default_rng(seed)
    counts["jitter"] = rng.random(len(counts))
    counts = counts.sort_values(["n", "jitter", "speaker_id"], ascending=[False, True, True])
    totals = np.zeros(n_folds, dtype=np.int64)
    assignment: dict[str, int] = {}
    for row in counts.itertuples(index=False):
        fold = int(np.argmin(totals))
        assignment[str(row.speaker_id)] = fold + 1
        totals[fold] += int(row.n)
    return assignment


def partition_matrix(
    frame: pd.DataFrame,
    assignment: dict[str, int],
    n_folds: int = 5,
    seed: int = 2026,
    selection_fraction: float = 0.075,
    calibration_fraction: float = 0.075,
) -> pd.DataFrame:
    speakers = sorted(frame["speaker_id"].astype(str).unique())
    rows = []
    for held_out_fold in range(1, n_folds + 1):
        outer_train = [speaker for speaker in speakers if assignment[speaker] != held_out_fold]
        rng = np.random.default_rng(seed + held_out_fold)
        shuffled = list(np.asarray(outer_train)[rng.permutation(len(outer_train))])
        selection_count = max(1, int(round(len(shuffled) * selection_fraction)))
        calibration_count = max(1, int(round(len(shuffled) * calibration_fraction)))
        if selection_count + calibration_count >= len(shuffled):
            raise ValueError("Insufficient outer-training speakers for three disjoint roles")
        selection = set(shuffled[:selection_count])
        calibration = set(shuffled[selection_count:selection_count + calibration_count])
        for speaker in speakers:
            if assignment[speaker] == held_out_fold:
                role = "test"
            elif speaker in selection:
                role = "selection"
            elif speaker in calibration:
                role = "calibration"
            else:
                role = "train"
            rows.append({"outer_fold": held_out_fold, "speaker_id": speaker, "role": role})
    return pd.DataFrame(rows)


def _load_vector(path: str | Path) -> np.ndarray:
    path = Path(path)
    if path.suffix == ".npy":
        value = np.load(path)
    elif path.suffix == ".npz":
        with np.load(path) as archive:
            key = "embedding" if "embedding" in archive.files else archive.files[0]
            value = archive[key]
    else:
        raise ValueError(f"Unsupported feature file: {path}")
    value = np.asarray(value, dtype=np.float32)
    if value.ndim > 1:
        value = value.mean(axis=0)
    return value


class FeatureDataset(Dataset):
    def __init__(self, frame: pd.DataFrame):
        if torch is None:
            raise ModuleNotFoundError("PyTorch is required to load model-ready feature batches")
        self.frame = frame.reset_index(drop=True)
        required = {"response_id", "speaker_id", *STREAMS, *LABELS}
        missing = sorted(required - set(self.frame.columns))
        if missing:
            raise ValueError(f"Missing feature columns: {missing}")

    def __len__(self) -> int:
        return len(self.frame)

    def __getitem__(self, index: int) -> dict:
        row = self.frame.iloc[index]
        item = {stream: torch.from_numpy(_load_vector(row[stream])) for stream in STREAMS}
        item["labels"] = torch.tensor([row[label] for label in LABELS], dtype=torch.long)
        item["response_id"] = str(row["response_id"])
        item["speaker_id"] = str(row["speaker_id"])
        return item
