from __future__ import annotations

import torch
import torch.nn.functional as F

from .model import CONSTRUCTS


def concordance_correlation(prediction: torch.Tensor, target: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    prediction = prediction.float()
    target = target.float()
    mean_p, mean_t = prediction.mean(), target.mean()
    var_p = ((prediction - mean_p) ** 2).mean()
    var_t = ((target - mean_t) ** 2).mean()
    covariance = ((prediction - mean_p) * (target - mean_t)).mean()
    return 2.0 * covariance / (var_p + var_t + (mean_p - mean_t) ** 2 + eps)


def orthogonality_loss(hidden: list[torch.Tensor], eps: float = 1e-8) -> torch.Tensor:
    normalized = []
    for value in hidden:
        centered = value - value.mean(dim=0, keepdim=True)
        normalized.append(centered / (centered.norm(p="fro") + eps))
    loss = normalized[0].new_zeros(())
    for left in range(len(normalized)):
        for right in range(left + 1, len(normalized)):
            loss = loss + (normalized[left].T @ normalized[right]).pow(2).sum()
    return loss


def joint_loss(output: dict, labels: torch.Tensor, ccc_weight: float = 0.20, evidence_weight: float = 0.05, orth_weight: float = 0.01) -> tuple[torch.Tensor, dict[str, float]]:
    ordinal = labels.new_zeros((), dtype=torch.float32)
    ccc = ordinal.clone()
    evidence = ordinal.clone()
    hidden = []
    for index, name in enumerate(CONSTRUCTS):
        probabilities = output[name]["probabilities"]
        target = labels[:, index]
        ordinal = ordinal + F.nll_loss(probabilities.log(), target)
        ccc = ccc + (1.0 - concordance_correlation(output[name]["expected"], target))
        if "alpha" in output[name]:
            one_hot = F.one_hot(target, num_classes=probabilities.shape[-1]).float()
            evidence = evidence + F.mse_loss(output[name]["alpha"] / output[name]["alpha"].sum(-1, keepdim=True), one_hot)
        hidden.append(output[name]["hidden"])
    ordinal = ordinal / len(CONSTRUCTS)
    ccc = ccc / len(CONSTRUCTS)
    evidence = evidence / len(CONSTRUCTS)
    orth = orthogonality_loss(hidden)
    total = ordinal + ccc_weight * ccc + evidence_weight * evidence + orth_weight * orth
    return total, {"ordinal": float(ordinal.detach()), "ccc": float(ccc.detach()), "evidence": float(evidence.detach()), "orthogonality": float(orth.detach())}
