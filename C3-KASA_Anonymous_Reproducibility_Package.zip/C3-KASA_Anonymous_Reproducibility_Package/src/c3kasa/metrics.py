from __future__ import annotations

import numpy as np
from sklearn.metrics import cohen_kappa_score, f1_score, mean_absolute_error, mean_squared_error

from .calibration import half_up


def ccc(target: np.ndarray, prediction: np.ndarray) -> float:
    target = np.asarray(target, dtype=float)
    prediction = np.asarray(prediction, dtype=float)
    covariance = np.mean((target - target.mean()) * (prediction - prediction.mean()))
    return float(2 * covariance / (target.var() + prediction.var() + (target.mean() - prediction.mean()) ** 2 + 1e-12))


def expected_score(probabilities: np.ndarray) -> np.ndarray:
    probabilities = np.asarray(probabilities, dtype=float)
    return probabilities @ np.arange(probabilities.shape[1], dtype=float)


def ece(probabilities: np.ndarray, labels: np.ndarray, bins: int = 15) -> float:
    probabilities = np.asarray(probabilities, dtype=float)
    labels = np.asarray(labels, dtype=int)
    confidence = probabilities.max(axis=1)
    prediction = probabilities.argmax(axis=1)
    edges = np.quantile(confidence, np.linspace(0, 1, bins + 1))
    edges[0], edges[-1] = -np.inf, np.inf
    total = len(labels)
    value = 0.0
    for index in range(bins):
        mask = (confidence > edges[index]) & (confidence <= edges[index + 1])
        if mask.any():
            value += mask.mean() * abs((prediction[mask] == labels[mask]).mean() - confidence[mask].mean())
    return float(value)


def brier(probabilities: np.ndarray, labels: np.ndarray) -> float:
    target = np.eye(probabilities.shape[1], dtype=float)[np.asarray(labels, dtype=int)]
    return float(np.mean(np.sum((probabilities - target) ** 2, axis=1)))


def metric_bundle(labels: np.ndarray, probabilities: np.ndarray) -> dict[str, float]:
    labels = np.asarray(labels, dtype=int)
    probabilities = np.asarray(probabilities, dtype=float)
    continuous = expected_score(probabilities)
    rounded = half_up(continuous)
    return {
        "qwk": float(cohen_kappa_score(labels, rounded, weights="quadratic")),
        "ccc": ccc(labels, continuous),
        "pearson": float(np.corrcoef(labels, continuous)[0, 1]),
        "mae": float(mean_absolute_error(labels, continuous)),
        "rmse": float(mean_squared_error(labels, continuous) ** 0.5),
        "macro_f1": float(f1_score(labels, rounded, average="macro", zero_division=0)),
        "exact": float(np.mean(labels == rounded)),
        "within_one": float(np.mean(np.abs(labels - rounded) <= 1)),
        "severe_disagreement": float(np.mean(np.abs(labels - rounded) >= 2)),
        "nll": float(-np.log(np.clip(probabilities[np.arange(len(labels)), labels], 1e-12, 1.0)).mean()),
        "brier": brier(probabilities, labels),
        "ece": ece(probabilities, labels),
    }
