from __future__ import annotations

import math

import numpy as np
try:
    import torch
except ModuleNotFoundError:
    torch = None


def class_probabilities_from_cumulative(cumulative: torch.Tensor) -> torch.Tensor:
    if torch is None:
        raise ModuleNotFoundError("PyTorch is required for probability calibration")
    pieces = [1.0 - cumulative[:, 0]]
    pieces.extend(cumulative[:, i - 1] - cumulative[:, i] for i in range(1, cumulative.shape[1]))
    pieces.append(cumulative[:, -1])
    probabilities = torch.stack(pieces, dim=-1).clamp_min(1e-7)
    return probabilities / probabilities.sum(-1, keepdim=True)


def fit_temperature(latent: torch.Tensor, thresholds: torch.Tensor, labels: torch.Tensor, max_iter: int = 100) -> float:
    if torch is None:
        raise ModuleNotFoundError("PyTorch is required for temperature fitting")
    log_temperature = torch.zeros((), dtype=latent.dtype, device=latent.device, requires_grad=True)
    optimizer = torch.optim.LBFGS([log_temperature], lr=0.1, max_iter=max_iter, line_search_fn="strong_wolfe")

    def closure():
        optimizer.zero_grad()
        temperature = log_temperature.exp().clamp_min(1e-4)
        cumulative = torch.sigmoid((latent[:, None] - thresholds[None, :]) / temperature)
        probabilities = class_probabilities_from_cumulative(cumulative)
        loss = torch.nn.functional.nll_loss(probabilities.log(), labels)
        loss.backward()
        return loss

    optimizer.step(closure)
    return float(log_temperature.detach().exp())


def half_up(values: np.ndarray) -> np.ndarray:
    return np.clip(np.floor(np.asarray(values, dtype=float) + 0.5), 0, 5).astype(int)


def higher_finite_quantile(values: np.ndarray, alpha: float) -> float:
    values = np.sort(np.asarray(values, dtype=float))
    if values.size == 0:
        raise ValueError("Quantile input is empty")
    index = min(values.size, int(math.ceil((values.size + 1) * (1.0 - alpha))))
    return float(values[index - 1])


def speaker_blocked_quantile(frame, score_column: str, speaker_column: str, alpha: float) -> float:
    per_speaker = []
    for _, group in frame.groupby(speaker_column, sort=True):
        per_speaker.append(higher_finite_quantile(group[score_column].to_numpy(), alpha))
    return higher_finite_quantile(np.asarray(per_speaker), alpha)
