from __future__ import annotations

from collections import OrderedDict

try:
    import torch
except ModuleNotFoundError:
    torch = None
from torch import nn
import torch.nn.functional as F


STREAMS = ("speech_semantic", "asr", "pronunciation_prosody", "morphosyntax", "prompt_content")
CONSTRUCTS = ("delivery", "language_use", "content")


class OrderedOrdinalHead(nn.Module):
    def __init__(self, dim: int, classes: int = 6):
        super().__init__()
        self.direction = nn.Linear(dim, 1)
        self.threshold_base = nn.Parameter(torch.tensor(-2.0))
        self.threshold_steps = nn.Parameter(torch.ones(classes - 2))
        self.classes = classes

    def thresholds(self) -> torch.Tensor:
        steps = F.softplus(self.threshold_steps) + 1e-4
        return torch.cat([self.threshold_base.view(1), self.threshold_base + torch.cumsum(steps, dim=0)])

    def forward(self, hidden: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        score = self.direction(hidden).squeeze(-1)
        cumulative = torch.sigmoid(score[:, None] - self.thresholds()[None, :])
        probs = [1.0 - cumulative[:, 0]]
        probs.extend(cumulative[:, i - 1] - cumulative[:, i] for i in range(1, self.classes - 1))
        probs.append(cumulative[:, -1])
        probabilities = torch.stack(probs, dim=-1).clamp_min(1e-7)
        probabilities = probabilities / probabilities.sum(dim=-1, keepdim=True)
        return probabilities, score


class EvidenceHead(nn.Module):
    def __init__(self, dim: int, classes: int = 6):
        super().__init__()
        self.strength = nn.Linear(dim, 1)
        self.classes = classes

    def forward(self, hidden: torch.Tensor, probabilities: torch.Tensor) -> dict[str, torch.Tensor]:
        scalar = F.softplus(self.strength(hidden)).clamp(1e-4, 100.0)
        alpha = 1.0 + scalar * probabilities
        total = alpha.sum(dim=-1)
        uncertainty = self.classes / total
        return {"strength": scalar.squeeze(-1), "alpha": alpha, "uncertainty": uncertainty}


class ConstructRouter(nn.Module):
    def __init__(self, dim: int, stream_count: int):
        super().__init__()
        self.score = nn.ModuleList([nn.Linear(dim * 2, 1) for _ in range(stream_count)])
        self.route = nn.ModuleList([nn.Linear(dim, dim) for _ in range(stream_count)])
        self.shared = nn.Linear(dim, dim)

    def forward(self, streams: list[torch.Tensor], shared: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        logits = torch.cat([layer(torch.cat([value, shared], dim=-1)) for layer, value in zip(self.score, streams)], dim=-1)
        gates = torch.softmax(logits, dim=-1)
        routed = torch.stack([layer(value) for layer, value in zip(self.route, streams)], dim=1)
        hidden = (gates.unsqueeze(-1) * routed).sum(dim=1) + self.shared(shared)
        return hidden, gates


class C3KASA(nn.Module):
    def __init__(self, input_dims: dict[str, int], common_dim: int = 512, classes: int = 6, dropout: float = 0.05):
        super().__init__()
        if tuple(input_dims) != STREAMS:
            missing = [name for name in STREAMS if name not in input_dims]
            if missing:
                raise ValueError(f"Missing input dimensions: {missing}")
        self.projections = nn.ModuleDict({
            name: nn.Sequential(nn.Linear(input_dims[name], common_dim), nn.LayerNorm(common_dim), nn.GELU(), nn.Dropout(dropout))
            for name in STREAMS
        })
        self.shared = nn.Sequential(nn.Linear(common_dim * len(STREAMS), common_dim), nn.LayerNorm(common_dim), nn.GELU())
        self.routers = nn.ModuleDict({name: ConstructRouter(common_dim, len(STREAMS)) for name in CONSTRUCTS})
        self.ordinal = nn.ModuleDict({name: OrderedOrdinalHead(common_dim, classes) for name in CONSTRUCTS})
        self.evidence = nn.ModuleDict({name: EvidenceHead(common_dim, classes) for name in CONSTRUCTS})
        self.classes = classes

    def forward(self, batch: dict[str, torch.Tensor]) -> dict[str, dict[str, torch.Tensor]]:
        streams = [self.projections[name](batch[name]) for name in STREAMS]
        shared = self.shared(torch.cat(streams, dim=-1))
        output: dict[str, dict[str, torch.Tensor]] = OrderedDict()
        class_values = torch.arange(self.classes, device=shared.device, dtype=shared.dtype)
        for name in CONSTRUCTS:
            hidden, gates = self.routers[name](streams, shared)
            probabilities, latent = self.ordinal[name](hidden)
            expected = (probabilities * class_values).sum(dim=-1)
            evidence = self.evidence[name](hidden, probabilities)
            output[name] = {
                "probabilities": probabilities,
                "expected": expected,
                "latent": latent,
                "gates": gates,
                "hidden": hidden,
                **evidence,
            }
        return output


class ParameterMatchedCrossAttention(nn.Module):
    def __init__(self, input_dims: dict[str, int], common_dim: int = 512, classes: int = 6, layers: int = 3, heads: int = 8, feedforward_dim: int = 2048, dropout: float = 0.05):
        super().__init__()
        self.projections = nn.ModuleDict({name: nn.Linear(input_dims[name], common_dim) for name in STREAMS})
        block = nn.TransformerEncoderLayer(common_dim, heads, feedforward_dim, dropout, batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(block, layers)
        self.residual_match = nn.Sequential(nn.Linear(common_dim, common_dim), nn.GELU(), nn.Linear(common_dim, common_dim))
        self.ordinal = nn.ModuleDict({name: OrderedOrdinalHead(common_dim, classes) for name in CONSTRUCTS})
        self.classes = classes

    def forward(self, batch: dict[str, torch.Tensor]) -> dict[str, dict[str, torch.Tensor]]:
        tokens = torch.stack([self.projections[name](batch[name]) for name in STREAMS], dim=1)
        hidden = self.encoder(tokens).mean(dim=1)
        hidden = hidden + self.residual_match(hidden)
        values = torch.arange(self.classes, device=hidden.device, dtype=hidden.dtype)
        output = OrderedDict()
        for name in CONSTRUCTS:
            probabilities, latent = self.ordinal[name](hidden)
            output[name] = {"probabilities": probabilities, "expected": (probabilities * values).sum(-1), "latent": latent, "hidden": hidden}
        return output
