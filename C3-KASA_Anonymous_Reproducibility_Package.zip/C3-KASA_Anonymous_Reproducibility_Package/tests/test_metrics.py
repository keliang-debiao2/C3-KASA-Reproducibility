import numpy as np

from c3kasa.calibration import half_up
from c3kasa.metrics import metric_bundle


def test_half_up_rounding():
    value = half_up(np.array([0.49, 0.50, 1.50, 4.50, 5.20]))
    assert value.tolist() == [0, 1, 2, 5, 5]


def test_metric_bundle():
    labels = np.array([0, 1, 2, 3, 4, 5])
    probabilities = np.eye(6) * 0.95 + 0.05 / 6
    probabilities = probabilities / probabilities.sum(axis=1, keepdims=True)
    result = metric_bundle(labels, probabilities)
    assert result["qwk"] > 0.99
    assert result["within_one"] == 1.0
