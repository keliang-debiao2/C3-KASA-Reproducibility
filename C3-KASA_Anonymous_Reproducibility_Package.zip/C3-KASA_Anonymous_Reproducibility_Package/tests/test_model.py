import torch

from c3kasa.model import C3KASA, STREAMS


def test_forward_shapes():
    dims = {"speech_semantic": 16, "asr": 12, "pronunciation_prosody": 10, "morphosyntax": 8, "prompt_content": 6}
    model = C3KASA(dims, common_dim=32, classes=6, dropout=0.0)
    batch = {name: torch.randn(4, dims[name]) for name in STREAMS}
    output = model(batch)
    assert set(output) == {"delivery", "language_use", "content"}
    for value in output.values():
        assert value["probabilities"].shape == (4, 6)
        assert torch.allclose(value["probabilities"].sum(-1), torch.ones(4), atol=1e-5)
        assert value["gates"].shape == (4, 5)
