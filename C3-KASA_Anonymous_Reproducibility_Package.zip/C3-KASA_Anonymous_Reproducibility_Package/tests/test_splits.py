import pandas as pd

from c3kasa.data import grouped_folds, partition_matrix


def test_speaker_disjoint_assignment():
    frame = pd.DataFrame({"speaker_id": ["a", "a", "b", "c", "c", "d"], "response_id": list("abcdef")})
    assignment = grouped_folds(frame, n_folds=3, seed=2026)
    assert set(assignment) == {"a", "b", "c", "d"}
    assert all(1 <= value <= 3 for value in assignment.values())


def test_partition_roles_are_disjoint():
    speakers = [f"s{index:02d}" for index in range(30)]
    frame = pd.DataFrame({"speaker_id": speakers, "response_id": speakers})
    assignment = grouped_folds(frame, n_folds=5, seed=2026)
    roles = partition_matrix(frame, assignment, n_folds=5, seed=2026)
    assert len(roles) == 150
    assert not roles.duplicated(["outer_fold", "speaker_id"]).any()
    assert set(roles["role"]) == {"train", "selection", "calibration", "test"}
    for fold, group in roles.groupby("outer_fold"):
        test_speakers = set(group.loc[group.role == "test", "speaker_id"])
        assert test_speakers == {speaker for speaker, assigned in assignment.items() if assigned == fold}
