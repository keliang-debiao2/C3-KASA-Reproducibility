# Reproduction protocol

## 1. Controlled data access

Obtain the English-L1, Asian-L1, and European-L1 Korean speech corpora from AI-Hub under the applicable provider terms. Do not commit audio, transcripts containing personal information, access tokens, or provider credentials.

## 2. Canonicalization and audit

Convert audio to mono 16 kHz signed 16-bit PCM. Verify file readability, speaker and prompt identifiers, labels, duration, and transcript availability. Remove unreadable records, invalid targets, exact duplicates, qualified near duplicates, and responses outside 0.8 to 120 seconds. Preserve internal pauses, hesitation, repetition, and self-repair.

## 3. Speaker-disjoint outer folds

Assign each learner to exactly one of five outer-test folds. Within the remaining outer-training speakers, create mutually exclusive model-training, model-selection, and independent-calibration partitions in the ratio 85%/7.5%/7.5%. All data-dependent preprocessing and empirical conformal quantiles are fitted without outer-test speakers.

## 4. Feature contracts

Store one pooled vector for each of the five online evidence streams. Sequence-level extraction may be retained in an external cache, but the manifest passed to the joint model must resolve to deterministic arrays with the dimensions in `configs/base.yaml`.

## 5. Training

Run seeds 2026 through 2030 for each outer fold. Use model-selection speakers for early stopping and hyperparameter choice. Average the five seed-specific uncalibrated probability vectors within each outer fold before calculating predictive metrics.

## 6. Calibration

Fit one temperature per construct on independent calibration speakers by six-class negative log-likelihood. Reconstruct calibrated class probabilities from calibrated cumulative probabilities. Use calibrated probabilities only for NLL, Brier score, ECE, and empirical interval construction.

## 7. Speaker-blocked empirical intervals

Calculate absolute nonconformity scores around the calibrated expected score. Select a higher finite-sample quantile within each calibration speaker and then a higher finite-sample quantile across calibration speakers. Do not interpolate. Clip interval endpoints to the 0-5 scale.

## 8. Transfer evaluation

Preserve mutually exclusive fixed-test, calibration-only, and adaptation-pool speakers. The 1%, 5%, and 10% adaptation sets are nested within the adaptation pool. Do not pool Asian-L1 and European-L1 records.

## 9. OTA evaluation

Select 600 outer-test responses from 600 speakers, 120 per outer fold. Freeze checkpoints, preprocessing, temperatures, and thresholds before capture. Evaluate each of the nine device-room conditions on the same 600 responses. Severe disagreement uses 1,800 construct predictions per condition.

## 10. Statistical analysis

Use the speaker as the resampling unit. Report clustered intervals, raw paired permutation p-values, Holm-adjusted p-values for the eight-comparison family, and the separately defined worst-group MAE comparison.
