# Anonymous review checklist

- No author name, affiliation, email address, ORCID, grant identifier, or institutional directory is present.
- No repository history, remote URL, issue tracker, or contributor metadata is included.
- No controlled audio, transcript, private label file, credential, token, or model weight is included.
- Paths are relative and do not expose local user names.
- Reference records are identified as manuscript-derived records, not fresh execution proof.
- All third-party assets remain subject to their own licenses and access conditions.
- The prohibited-token validator passes before archive creation.
