# Data contract

The repository never assumes a provider-specific local directory name. Every record is resolved through explicit manifests.

## Response manifest

Required columns are `response_id`, `speaker_id`, `prompt_id`, `audio_path`, `delivery`, `language_use`, and `content`. Labels must be integers in 0 through 5. `response_id` must be unique. `speaker_id` is the exclusive grouping key for all folds.

## Feature manifest

Each row maps one `response_id` to five `.npy` or `.npz` files: `speech_semantic`, `asr`, `pronunciation_prosody`, `morphosyntax`, and `prompt_content`. An `.npz` archive should store the pooled vector under `embedding`; otherwise the first array is read. Higher-rank arrays are mean pooled along the first axis.

## Prediction contract

Long-form prediction files contain `response_id`, `speaker_id`, `outer_fold`, `seed`, `construct`, `label`, `p0` through `p5`, `expected`, and `uncertainty`. Calibration files additionally contain calibrated probability columns, `calibrated_expected`, and `temperature`.

## Leakage boundary

Outer-test speakers cannot contribute to training, early stopping, feature normalization, vocabulary fitting, class weights, auxiliary adaptation, temperature scaling, conformal quantiles, or threshold decisions. Frozen pretrained models may process outer-test inputs only during evaluation.
