# Result contract

## Primary fold summary

Calculate D/L/C metrics independently inside each outer fold after averaging seed probabilities. Macro values are the unweighted mean of the three constructs. Report the unweighted mean and sample standard deviation over five folds.

## Rounding

Clip continuous expected scores to 0 through 5 and apply half-up rounding. A construct-level severe disagreement occurs when the rounded prediction and provider score differ by at least two levels. A response-level severe disagreement occurs when at least one construct satisfies that rule.

## Probability paths

Uncalibrated ordinal probabilities determine predictive metrics and rounded categories. Independently calibrated probabilities determine NLL, Brier score, ECE, and empirical intervals. Evidence-strength uncertainty determines retrospective ranking only.

## Reference record status

Reference records contain manuscript values and expected field structure. Fresh executions must write separate run directories and must not overwrite the reference records.
