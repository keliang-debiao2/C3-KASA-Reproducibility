# C3-KASA Anonymous Reproducibility Package

This repository contains the implementation contracts, model code, configuration files, evaluation utilities, statistical routines, table builders, and manuscript-metric reference records for **C3-KASA: Construct-Specific Cross-Modal Ordinal Scoring with Calibrated Uncertainty for L2 Korean Speaking Assessment**.

The repository is prepared for double-blind review. It contains no author names, affiliations, email addresses, institutional paths, repository history, or private credentials.

## Scope

The package supports the following workflows:

- speaker-disjoint five-fold data auditing and partitioning;
- five-stream feature loading for speech semantics, ASR states, pronunciation-prosody, Korean morphosyntax, and prompt content;
- construct-specific gated routing with a limited shared bottleneck;
- cumulative ordinal scoring and evidence-strength estimation;
- the parameter-matched cross-attention control;
- independent temperature scaling and speaker-blocked empirical conformal intervals;
- same-provider Asian-L1 and European-L1 transfer partitions;
- controlled acoustic and over-the-air evaluation;
- subgroup auditing, clustered confidence intervals, paired permutation tests, and table reconstruction.

The AI-Hub corpora and third-party model weights are controlled or separately licensed and are not redistributed. Authorized users connect local data through the manifest schemas in `schemas/` and the directory rules in `docs/DATA_CONTRACT.md`.

## Reference records

Files under `reference_logs/` and `artifacts/reference_metrics/` encode the values reported in the manuscript and the required logging schema. They are included for pipeline validation and AI-guided reconstruction. They are not evidence that the full training workload was executed inside this archive. A valid reproduction must create a new run directory, preserve its configuration hash, and retain machine-generated logs and predictions.

## Installation

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e .
```

Optional backbone extraction requires the model providers' approved access procedures and licenses.

## Repository validation

```bash
python scripts/validate_repository.py
python scripts/run_unit_checks.py
```

## Data preparation

1. Obtain the three AI-Hub speech corpora through the provider's access process.
2. Canonicalize audio to mono 16 kHz signed 16-bit PCM.
3. Build `data/authorized/response_manifest.csv` using `schemas/response_manifest.schema.json`.
4. Generate five-stream feature files and `data/authorized/feature_manifest.csv`.
5. Run the audit and fold builder.

```bash
python scripts/audit_data.py --manifest data/authorized/response_manifest.csv --out runs/audit
python scripts/make_splits.py --manifest data/authorized/response_manifest.csv --out runs/splits
```

## Primary five-fold workflow

```bash
python scripts/train_outer_fold.py --config configs/base.yaml --fold 1 --run-dir runs/primary/fold_1
python scripts/predict_outer_fold.py --checkpoint runs/primary/fold_1/model.pt --config configs/base.yaml --fold 1 --role calibration --out runs/primary/fold_1/calibration_predictions.csv
python scripts/calibrate_outer_fold.py --predictions runs/primary/fold_1/calibration_predictions.csv --out runs/primary/fold_1/calibration.json
python scripts/predict_outer_fold.py --checkpoint runs/primary/fold_1/model.pt --config configs/base.yaml --fold 1 --role test --calibration runs/primary/fold_1/calibration.json --out runs/primary/fold_1/test_predictions.csv
python scripts/evaluate_outer_fold.py --predictions runs/primary/fold_1/test_predictions.csv --out runs/primary/fold_1/test_metrics.json
```

Repeat for folds 1 through 5 and seeds 2026 through 2030. Seed probabilities are averaged within each outer fold before predictive metrics and paired inference.

## Parameter-matched control

```bash
python scripts/run_parameter_matched_control.py --config configs/model/parameter_matched_cross_attention.yaml --run-dir runs/parameter_matched
```

## Transfer, robustness, and statistics

```bash
python scripts/run_transfer.py --config configs/evaluation/transfer.yaml --run-dir runs/transfer
python scripts/run_ota.py --config configs/evaluation/ota.yaml --run-dir runs/ota
python scripts/run_statistics.py --predictions-root runs --out runs/statistics
python scripts/build_report_tables.py --metrics-root runs --out runs/tables
```

## Reproduction boundary

Predictive metrics use uncalibrated ordinal probabilities. NLL, Brier score, ECE, and empirical interval construction use independently temperature-scaled probabilities. Retrospective disagreement-risk ranking uses the separate evidence-strength uncertainty score. Outer-test speakers are excluded from model fitting, model selection, calibration, auxiliary fitting, vocabulary fitting, class weighting, and empirical conformal quantiles.
